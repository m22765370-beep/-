package com.raneceraft.game

import android.app.Activity
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import com.android.vending.billing.IInAppBillingService
import org.json.JSONObject
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

class MyketBilling(
    private val act: Activity,
    private val rsaKey: String,
    private val cb: Callback
) {
    interface Callback {
        fun onPurchased(sku: String)
        fun onFailed(msg: String)
        fun onOwned(skus: List<String>)
    }

    private val main = Handler(Looper.getMainLooper())
    private var service: IInAppBillingService? = null
    private val REQ = 7421
    private val BIND = "ir.mservices.market.InAppBillingService.BIND"
    private val MARKET = "ir.mservices.market"

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            service = IInAppBillingService.Stub.asInterface(b)
            restore()
        }
        override fun onServiceDisconnected(n: ComponentName?) { service = null }
    }

    fun start() {
        try {
            val i = Intent(BIND).setPackage(MARKET)
            act.bindService(i, conn, Context.BIND_AUTO_CREATE)
        } catch (e: Exception) { }
    }

    fun stop() {
        try { act.unbindService(conn) } catch (e: Exception) { }
        service = null
    }

    private fun consumable(sku: String) = sku.startsWith("coins_")

    fun buy(sku: String) {
        val s = service
        if (s == null) { cb.onFailed("مایکت نصب نیست یا وصل نشد"); start(); return }
        try {
            val b = s.getBuyIntent(3, act.packageName, sku, "inapp", "")
            val rc = b.getInt("RESPONSE_CODE", 6)
            if (rc == 7) { // already owned
                if (consumable(sku)) restore() else main.post { cb.onPurchased(sku) }
                return
            }
            if (rc != 0) { cb.onFailed("خرید ممکن نشد ($rc)"); return }
            @Suppress("DEPRECATION")
            val pi = b.getParcelable<PendingIntent>("BUY_INTENT")
            if (pi == null) { cb.onFailed("خرید ممکن نشد"); return }
            act.startIntentSenderForResult(pi.intentSender, REQ, Intent(), 0, 0, 0)
        } catch (e: Exception) {
            cb.onFailed("خطا در پرداخت")
        }
    }

    fun handleResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQ) return false
        val rc = data?.getIntExtra("RESPONSE_CODE", 6) ?: 6
        val json = data?.getStringExtra("INAPP_PURCHASE_DATA")
        val sig = data?.getStringExtra("INAPP_DATA_SIGNATURE")
        if (resultCode != Activity.RESULT_OK || rc != 0 || json == null || sig == null) {
            cb.onFailed("خرید انجام نشد"); return true
        }
        Thread {
            if (!verify(json, sig)) { main.post { cb.onFailed("خرید معتبر نیست") }; return@Thread }
            try {
                val o = JSONObject(json)
                val sku = o.getString("productId")
                val token = o.getString("purchaseToken")
                if (o.optInt("purchaseState", 0) != 0) { main.post { cb.onFailed("خرید انجام نشد") }; return@Thread }
                if (consumable(sku)) service?.consumePurchase(3, act.packageName, token)
                main.post { cb.onPurchased(sku) }
            } catch (e: Exception) { main.post { cb.onFailed("خطا در پرداخت") } }
        }.start()
        return true
    }

    // owned items: consumables left over are consumed + granted, the rest are restored silently
    fun restore() {
        val s = service ?: return
        Thread {
            try {
                val b = s.getPurchases(3, act.packageName, "inapp", null)
                if (b.getInt("RESPONSE_CODE", 6) != 0) return@Thread
                val datas = b.getStringArrayList("INAPP_PURCHASE_DATA_LIST") ?: return@Thread
                val sigs = b.getStringArrayList("INAPP_DATA_SIGNATURE_LIST") ?: return@Thread
                val owned = ArrayList<String>()
                for (i in datas.indices) {
                    if (!verify(datas[i], sigs[i])) continue
                    val o = JSONObject(datas[i])
                    val sku = o.getString("productId")
                    if (o.optInt("purchaseState", 0) != 0) continue
                    if (consumable(sku)) {
                        s.consumePurchase(3, act.packageName, o.getString("purchaseToken"))
                        main.post { cb.onPurchased(sku) }
                    } else owned.add(sku)
                }
                if (owned.isNotEmpty()) main.post { cb.onOwned(owned) }
            } catch (e: Exception) { }
        }.start()
    }

    private fun verify(data: String, sig: String): Boolean = try {
        val key = KeyFactory.getInstance("RSA")
            .generatePublic(X509EncodedKeySpec(Base64.decode(rsaKey, Base64.DEFAULT)))
        val v = Signature.getInstance("SHA1withRSA")
        v.initVerify(key)
        v.update(data.toByteArray())
        v.verify(Base64.decode(sig, Base64.DEFAULT))
    } catch (e: Exception) { false }
}
