package com.raneceraft.game

object Config {
    // Adivery app id
    const val ADIVERY_APP_ID = "94fd3240-7d17-4da8-b4a8-3787208cbf66"

    // Rewarded placement id from the Adivery panel (this one is Adivery's TEST placement - replace it with yours)
    const val REWARDED_PLACEMENT = "3f97dc4d-3e09-4024-acaf-931862c03ba8"

    // Myket public key (RSA, base64)
    const val MYKET_RSA_KEY =
        "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCAR93FKU2FYwzinaRwTksdlfHtA+u8c6iLGtK0hgqRUU3v4sJ7iv5CF6r7POpL//Mjr0EsAebEpZtf/Sp+abGz/gVUrcnD4vDO0absqZ2BnBY7cOBPEoYbscmHBXvXrgA0rW9/3GyOJsRq8NBJIMxwmpaFlEEOZ/+M6lHosohiRwIDAQAB"
}
