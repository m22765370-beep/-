package com.raneceraft.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import com.adivery.sdk.Adivery
import com.adivery.sdk.AdiveryListener
import org.json.JSONArray

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var billing: MyketBilling
    private var adShowing = false

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun adResult(r: String) {
        if (!adShowing) return
        adShowing = false
        js("window.onRewardedResult('$r')")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        web.setBackgroundColor(0xFF0D0620.toInt())
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }

        // ---- Myket billing ----
        billing = MyketBilling(this, Config.MYKET_RSA_KEY, object : MyketBilling.Callback {
            override fun onPurchased(sku: String) {
                js("window.onStorePurchase('${clean(sku)}',true)")
            }
            override fun onFailed(msg: String) {
                runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
                js("window.onStorePurchase('',false)")
            }
            override fun onOwned(skus: List<String>) {
                val arr = JSONArray(skus.map { clean(it) }).toString()
                js("(function t(n){if(window.onStoreRestore){$arr.forEach(function(s){window.onStoreRestore(s)})}else if(n<60)setTimeout(function(){t(n+1)},1000)})(0)")
            }
        })
        billing.start()

        // ---- Adivery ads ----
        try {
            Adivery.configure(application, Config.ADIVERY_APP_ID)
            Adivery.addGlobalListener(object : AdiveryListener() {
                override fun onRewardedAdClosed(placement: String, isRewarded: Boolean) {
                    adResult(if (isRewarded) "rewarded" else "closed")
                }
            })
            Adivery.prepareRewardedAd(this, Config.REWARDED_PLACEMENT)
        } catch (e: Exception) { }

        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun purchase(sku: String) {
                runOnUiThread { billing.buy(clean(sku)) }
            }
        }, "Android")

        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun isRewardedReady(): Boolean = try { Adivery.isLoaded(Config.REWARDED_PLACEMENT) } catch (e: Exception) { false }

            @JavascriptInterface
            fun showRewarded(key: String?) {
                runOnUiThread {
                    try {
                        if (Adivery.isLoaded(Config.REWARDED_PLACEMENT)) {
                            adShowing = true
                            Adivery.showAd(Config.REWARDED_PLACEMENT)
                        } else {
                            Adivery.prepareRewardedAd(this@MainActivity, Config.REWARDED_PLACEMENT)
                            adShowing = true
                            adResult("failed")
                        }
                    } catch (e: Exception) {
                        adShowing = true
                        adResult("failed")
                    }
                }
            }
        }, "AndroidAds")

        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun clean(s: String) = s.filter { it.isLetterOrDigit() || it == '_' }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (!billing.handleResult(requestCode, resultCode, data)) super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onDestroy() { billing.stop(); web.destroy(); super.onDestroy() }
}
